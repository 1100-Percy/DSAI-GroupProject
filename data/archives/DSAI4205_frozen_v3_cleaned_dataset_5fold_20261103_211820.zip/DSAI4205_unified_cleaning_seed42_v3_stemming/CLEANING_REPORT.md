# Stemming extension to unified cleaned dataset

This release applies Snowball English stemming AFTER the existing POS-aware WordNet
lemmatization. It is a combined lemma-then-stem pipeline, not an isolated stemming
ablation or proof that both operations improve performance. No model was trained.
The original v2 release is unchanged and remains the lemmatization-only reference.

Mention names and URL hostname words bypass both morphology steps. Negation,
protected pronouns and existing markers remain intact. No stopwords are removed.
Stemmed outputs can be non-words and can conflate different meanings. This is a
rule-based normalization choice, not a semantic repair. Original and repaired
text, as well as the pre-stemming lemmatized text, are retained for audit only.
All future models consume the same final Phrase in train.csv/test.csv.

Membership is inherited from v2: 563 training rows and 397 official test rows.
Original labels/order, the 33 training exclusions and all five group-aware fold
indices are unchanged. No new identical-input cross-test or multi-group collisions
were found. Existing provenance uncertainty and residual damage remain unchanged;
the original v2 cleaning report is saved as PARENT_CLEANING_REPORT.md.

## Transformation summary

| Split | Rows | Changed rows | Changed token occurrences |
|---|---:|---:|---:|
| train | 563 | 491 | 1571 |
| test | 397 | 341 | 1068 |

## Frequent transformations across retained train and test

| Lemma | Stem | Occurrences |
|---|---|---:|
| really | realli | 54 |
| people | peopl | 44 |
| why | whi | 43 |
| please | pleas | 33 |
| only | onli | 31 |
| try | tri | 28 |
| league | leagu | 24 |
| because | becaus | 24 |
| another | anoth | 21 |
| google | googl | 21 |
| someone | someon | 19 |
| series | seri | 18 |
| update | updat | 17 |
| any | ani | 17 |
| duty | duti | 16 |


See stemming_token_audit.csv for every changed token and its original source row,
lemma, stem, POS and final token index. stemming_summary.csv is the split summary.
Audit views include lemmatized_text and final model_text. Audit columns must not
be used as model features or an alternative model input for this release.
No claim about classification accuracy is made; training remains unauthorized.
