"""Independently verify frozen CSV membership, partitions, hashes and ZIP."""

import argparse
import hashlib
import json
import string
import unicodedata
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd


def verify(dest: Path) -> dict:
    hashes = json.loads((dest / "SHA256SUMS.json").read_text(encoding="utf-8"))
    actual = {p.relative_to(dest).as_posix() for p in dest.rglob("*") if p.is_file()}
    assert actual == set(hashes) | {"SHA256SUMS.json"}
    for name, expected in hashes.items():
        assert hashlib.sha256((dest / name).read_bytes()).hexdigest() == expected, name
    config = json.loads((dest / "dataset_config.json").read_text(encoding="utf-8"))
    main = {s: pd.read_csv(dest / f"{s}.csv", keep_default_na=False) for s in ["train", "test"]}
    views = {s: pd.read_csv(dest / f"{s}_audit_views.csv", keep_default_na=False)
             for s in ["train", "test"]}
    raw_test = pd.read_csv(dest / "raw_course_inputs/testdata.csv", keep_default_na=False)
    pd.testing.assert_frame_equal(raw_test, views["test"][["Phrase", "Sentiment"]])
    assert len(main["test"]) == 397
    for split, frame in main.items():
        assert frame.columns.tolist() == ["Phrase", "Sentiment"]
        assert len(frame) == config[f"{split}_rows"]
        assert frame.Phrase.str.strip().ne("").all()
        assert frame.Phrase.eq(frame.Phrase.str.lower()).all()
        assert not frame.Phrase.map(lambda s: any(
            c in string.punctuation or unicodedata.category(c).startswith("P") for c in s)).any()
        assert frame.Phrase.tolist() == views[split].model_text.tolist()
        assert frame.Sentiment.tolist() == views[split].Sentiment.tolist()
    for col in ["canonical_text", "group_id", "model_text", "source_group_id"]:
        assert not (set(views["train"][col]) - {""}) & (set(views["test"][col]) - {""}), col
    validation_counts = np.zeros(len(main["train"]), dtype=int)
    assignments = pd.read_csv(dest / "fold_assignments.csv")
    for fold in range(1, 6):
        indices = {}
        for split in ["train", "validation"]:
            index_frame = pd.read_csv(dest / f"fold_{fold}/{split}_indices.csv")
            idx = index_frame.row_index.to_numpy()
            assert len(idx) == len(set(idx))
            indices[split] = idx
            subset = pd.read_csv(dest / f"fold_{fold}/{split}.csv", keep_default_na=False)
            pd.testing.assert_frame_equal(subset, main["train"].iloc[idx].reset_index(drop=True))
            assert index_frame.sample_id.tolist() == views["train"].iloc[idx].sample_id.tolist()
        fit, val = indices["train"], indices["validation"]
        assert set(fit).isdisjoint(val)
        assert set(fit) | set(val) == set(range(len(main["train"])))
        assert set(views["train"].iloc[fit].group_id).isdisjoint(
            views["train"].iloc[val].group_id)
        assert assignments.iloc[val].validation_fold.eq(fold).all()
        validation_counts[val] += 1
    assert (validation_counts == 1).all()
    for name, expected in config["source_hashes"].items():
        assert hashlib.sha256((dest / "raw_course_inputs" / name).read_bytes()).hexdigest() == expected
    archive = dest.with_suffix(".zip")
    if archive.exists():
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None
            assert set(z.namelist()) == {dest.name + "/" + name for name in actual}
            for name in actual:
                assert z.read(dest.name + "/" + name) == (dest / name).read_bytes()
    return {"verified_files": len(actual), "train_rows": len(main["train"]),
            "test_rows": len(main["test"]), "group_overlap": 0,
            "validation_appearances_per_row": 1, "zip_checked": archive.exists()}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    print(json.dumps(verify(parser.parse_args().directory), indent=2))
