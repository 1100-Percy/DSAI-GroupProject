"""Freeze v3: v2's fixed membership and folds with lemma-then-Snowball input."""

from __future__ import annotations

import argparse
import json
import shutil
import sys
import tempfile
import zipfile
from collections import Counter
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))
from verify_unified_dataset import verify

from dsai4205_twitter.unified_data import initialize_nltk, normalize_input, sha256

NAME = "DSAI4205_unified_cleaning_seed42_v3_stemming"
PARENT = ROOT / "outputs/DSAI4205_unified_cleaning_seed42_v2"


def save_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def save_csv(path: Path, frame: pd.DataFrame) -> None:
    export = frame.copy()
    for col in export.columns:
        export[col] = export[col].map(
            lambda x: json.dumps(x, ensure_ascii=False) if isinstance(x, (list, dict)) else x)
    export.to_csv(path, index=False, encoding="utf-8-sig")
    reread = pd.read_csv(path, keep_default_na=False)
    assert len(reread) == len(export)
    for col in export.select_dtypes(include="object").columns:
        assert reread[col].astype(str).tolist() == export[col].astype(str).tolist(), col


def build(staging: Path) -> dict:
    verify(PARENT)
    initialize_nltk(ROOT)
    # Carry forward membership, source evidence and all immutable fold indices.
    for p in PARENT.iterdir():
        if p.name in {"SHA256SUMS.json", "code"}:
            continue
        if p.is_dir():
            shutil.copytree(p, staging / p.name)
        else:
            shutil.copyfile(p, staging / p.name)
    course = pd.read_csv(PARENT / "all_rows_audit.csv", keep_default_na=False)
    previous_inputs = course.model_text.tolist()
    events, token_rows, stems, summaries = [], [], [], []
    for row in course.itertuples(index=False):
        text, details = normalize_input(row.repaired_text, morphology="lemma_stem")
        assert details["lemmatized_text"] == row.model_text, row.sample_id
        stems.append(text)
        events.append({"sample_id": row.sample_id, **details})
        for change in details["stem_changes"]:
            token_rows.append({"sample_id": row.sample_id, "split": row.split,
                "source_row_index": row.source_row_index,
                "retained": row.exclusion_reason == "", **change})
    course.insert(course.columns.get_loc("model_text"), "lemmatized_text", previous_inputs)
    course["model_text"] = stems
    active = course[course.exclusion_reason.eq("")]
    train = active[active.split.eq("train")].reset_index(drop=True)
    test = active[active.split.eq("test")].reset_index(drop=True)
    assert not set(train.model_text) & set(test.model_text), "New cross-test stemming collision"
    # Do not silently keep folds that would split new identical stemmed inputs.
    assert train.groupby("model_text").group_id.nunique().max() == 1, (
        "New stemming collision connects old groups; needs a separately versioned fold rebuild")
    save_csv(staging / "all_rows_audit.csv", course)
    save_csv(staging / "excluded_training_rows.csv", course[course.exclusion_reason.ne("")])
    save_csv(staging / "normalized_input_collisions.csv", course[
        course.duplicated("model_text", keep=False)])
    save_csv(staging / "text_transformation_audit.csv", pd.DataFrame(events))
    token_frame = pd.DataFrame(token_rows, columns=["sample_id", "split", "source_row_index",
        "retained", "token", "lemma", "stem", "pos", "output_token_index"])
    save_csv(staging / "stemming_token_audit.csv", token_frame)
    master = {}
    for split, frame in (("train", train), ("test", test)):
        parent_views = pd.read_csv(PARENT / f"{split}_audit_views.csv", keep_default_na=False)
        assert frame.sample_id.tolist() == parent_views.sample_id.tolist()
        assert frame.Sentiment.tolist() == parent_views.Sentiment.tolist()
        assert frame.group_id.tolist() == parent_views.group_id.tolist()
        master[split] = frame[["model_text", "Sentiment"]].rename(columns={"model_text": "Phrase"})
        save_csv(staging / f"{split}.csv", master[split])
        views = frame.copy()
        views.insert(0, "row_index", range(len(views)))
        save_csv(staging / f"{split}_audit_views.csv", views)
        summaries.append({"split": split, "rows": len(frame),
            "changed_rows": int(frame.model_text.ne(frame.lemmatized_text).sum()),
            "changed_token_occurrences": int((token_frame.split.eq(split)
                & token_frame.retained).sum()),
            "word_token_count_before": int(frame.lemmatized_text.str.split().str.len().sum()),
            "word_token_count_after": int(frame.model_text.str.split().str.len().sum())})
    save_csv(staging / "stemming_summary.csv", pd.DataFrame(summaries))
    for fold in range(1, 6):
        for part in ["train", "validation"]:
            idx = pd.read_csv(PARENT / f"fold_{fold}/{part}_indices.csv").row_index
            save_csv(staging / f"fold_{fold}/{part}.csv", master["train"].iloc[idx].reset_index(drop=True))
    config = json.loads((PARENT / "dataset_config.json").read_text(encoding="utf-8"))
    config.update({"dataset_version": NAME, "rules_version": "unified_course_v3_lemma_snowball",
        "parent_dataset_version": PARENT.name,
        "parent_manifest_sha256": sha256(PARENT / "SHA256SUMS.json"),
        "morphology_pipeline": ["WordNet POS lemmatization", "Snowball English stemming"],
        "stemming": {"algorithm": "nltk.stem.SnowballStemmer(english, ignore_stopwords=False)",
            "order": "after lemmatization", "eligible": "ASCII alphabetic words of length >=3",
            "exceptions": "mention/domain tokens; existing protected pronouns, negation and markers",
            "stopwords_removed": False},
        "parent_membership_labels_order_groups_and_folds_unchanged": True,
        "stemming_summary": summaries, "historical_results_apply": False,
        "model_training_performed": False})
    config["token_audit_counts_all_original_rows"]["stem_changes"] = len(token_rows)
    save_json(staging / "dataset_config.json", config)
    verification = json.loads((PARENT / "verification.json").read_text(encoding="utf-8"))
    verification.update({"parent_membership_labels_order_groups_and_folds_unchanged": True,
                         "new_stemming_cross_split_collisions": 0,
                         "new_stemming_multi_group_collisions": 0})
    save_json(staging / "verification.json", verification)
    examples = Counter((r["lemma"], r["stem"]) for r in token_rows if r["retained"])
    report = """# Stemming extension to unified cleaned dataset

This release applies Snowball English stemming AFTER the existing POS-aware WordNet
lemmatization. It is a combined lemma-then-stem pipeline, not an isolated stemming
ablation or proof that both operations improve performance. No model was trained.
The original v2 release is unchanged and remains the lemmatization-only reference.

Mention names and URL hostname words bypass both morphology steps. Negation,
protected pronouns and existing markers remain intact. No stopwords are removed.
Stemmed outputs can be non-words and can conflate different meanings. This is a
rule-based normalization choice, not a semantic repair. Original and repaired
text, as well as the pre-stemming lemmatized text, are retained for audit only.
All future models consume the same final Phrase in train.csv/test.csv.

Membership is inherited from v2: 563 training rows and 397 official test rows.
Original labels/order, the 33 training exclusions and all five group-aware fold
indices are unchanged. No new identical-input cross-test or multi-group collisions
were found. Existing provenance uncertainty and residual damage remain unchanged;
the original v2 cleaning report is saved as PARENT_CLEANING_REPORT.md.

## Transformation summary

"""
    report += "| Split | Rows | Changed rows | Changed token occurrences |\n|---|---:|---:|---:|\n"
    for summary in summaries:
        report += (f"| {summary['split']} | {summary['rows']} | {summary['changed_rows']} | "
                   f"{summary['changed_token_occurrences']} |\n")
    report += "\n## Frequent transformations across retained train and test\n\n"
    report += "| Lemma | Stem | Occurrences |\n|---|---|---:|\n"
    report += "".join(f"| {a} | {b} | {n} |\n" for (a, b), n in examples.most_common(15))
    report += """

See stemming_token_audit.csv for every changed token and its original source row,
lemma, stem, POS and final token index. stemming_summary.csv is the split summary.
Audit views include lemmatized_text and final model_text. Audit columns must not
be used as model features or an alternative model input for this release.
No claim about classification accuracy is made; training remains unauthorized.
"""
    shutil.copyfile(PARENT / "CLEANING_REPORT.md", staging / "PARENT_CLEANING_REPORT.md")
    (staging / "CLEANING_REPORT.md").write_text(report, encoding="utf-8")
    (staging / "README.md").write_text(f"""# Unified cleaned dataset v3 with stemming

Frozen dataset only. No training or embedding extraction.
563 training / 397 official test; same members, labels, order and five group folds
as {PARENT.name}. Model input is the final lowercase Phrase in the two-column
train.csv/test.csv and supplied folds. v2 normalization is followed by Snowball
English stemming after WordNet lemmatization. Mention identity, hostname tokens
and protected negation/pronouns bypass stemming; stopwords are not removed.

Read CLEANING_REPORT.md for effects, limits and token-level audits, and
PARENT_CLEANING_REPORT.md for inherited source-ID, residual encoding damage,
exclusions and external-provenance limitations. No external source was re-read
or restored in this extension. v2's provenance metadata is inherited unchanged.
This release does not claim better model accuracy than v2.

Reproduce in the existing project environment with the frozen v2 parent present:
python scripts/data/freeze_stemmed_dataset.py
Add --freeze to publish this version; existing releases refuse overwrite.
Verify: python scripts/data/verify_unified_dataset.py outputs/{NAME}
The package includes raw course inputs, all row-level audit records, frozen fold
indices, source/linguistic resource hashes and code snapshots. Every other package
file is hashed by SHA256SUMS.json. Future rule changes require a new release.
""", encoding="utf-8")
    (staging / "code").mkdir()
    for p in (Path(__file__), ROOT / "src/dsai4205_twitter/unified_data.py",
              ROOT / "scripts/data/verify_unified_dataset.py"):
        shutil.copyfile(p, staging / "code" / p.name)
    save_json(staging / "SHA256SUMS.json", {p.relative_to(staging).as_posix(): sha256(p)
        for p in sorted(staging.rglob("*")) if p.is_file()})
    verify(staging)
    return config


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--freeze", action="store_true")
    args = parser.parse_args()
    dest = ROOT / "outputs" / NAME
    archive = dest.with_suffix(".zip")
    if args.freeze and (dest.exists() or archive.exists()):
        raise FileExistsError(f"Refusing to overwrite frozen release: {dest}")
    staging = Path(tempfile.mkdtemp(prefix="unified_v3_", dir=ROOT / "tmp"))
    config = build(staging)
    if args.freeze:
        staging.rename(dest)
        with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
            for p in sorted(dest.rglob("*")):
                if p.is_file():
                    z.write(p, f"{NAME}/{p.relative_to(dest).as_posix()}")
        print(json.dumps(verify(dest), indent=2))
        print(f"FROZEN: {archive}")
    else:
        print(f"REVIEW STAGING: {staging}")
    print(json.dumps(config["stemming_summary"], indent=2))


if __name__ == "__main__":
    main()
