# Unified dataset cleaning report

## Release scope

Dataset only; no training or embedding extraction. Common Phrase input is lowercase,
punctuation-free and POS-lemmatized. Mention identity words and URL hostname words
are retained. Original labels are never revised. All models must consume the same
master Phrase; raw/repaired audit views are not alternative model inputs.

## Membership changes

- Original training rows: 596.
- Conflicting canonical-label rows excluded: 5.
- Exact train/test-overlap rows excluded: 1.
- Additional confirmed cross-test source rows excluded: 27.
- Final training rows: 563. Official test rows: 397.
- Other exclusions: {}.

Inspect excluded_training_rows.csv for every original source index, raw text, label
and reason. Different-source templates are retained. Provenance IDs are audit-only
external information; text/labels/entities from external sources are not restored
or used for fitting. Exact and damage-compatible unique provenance matches are
separately identified. Damage matching changes only lineage metadata.

## Damage and limitations

- Repaired training texts with U+FFFD: 44.
- Repaired test texts with U+FFFD: 31.
- Model-input training texts with U+FFFD: 34.
- Model-input test texts with U+FFFD: 20.
- Retained provenance status: {"train": {"unique": 559, "unmatched": 2, "ambiguous": 2}, "test": {"unique": 392, "unmatched": 4, "ambiguous": 1}}.

Some question marks in raw text are parts of damaged encoding sequences. See
surface_feature_summary.csv for the SAME retained rows before and after repair.
Do not interpret raw '?' prevalence as a clean linguistic question statistic.
Lowercasing loses all-caps emphasis; punctuation removal loses emphasis/boundaries;
lemmatization may conflate forms or mis-tag informal text. Uppercase counts and
original punctuation remain in audit views. URL normalization loses path/query
meaning and does not validate live destinations. Unrecognized broken URL-like
spans are flagged and not guessed. No spelling, grammar, lost-character or target
label correction is performed. Unresolved provenance means no claim of exhaustive
elimination of all possible shared origins. Template similarity remains possible.

## Validation and use

Five group-aware stratified folds use seed 42. All confirmed provenance variants
and identical-input components stay within a fold. There are
13 multirow groups in retained training.
Master row indices and original source row indices are zero-based. Each training
row is validation once. Official test is excluded from CV and its original text,
label and order are preserved in audit; only its exported model Phrase changes.

No old score applies to this dataset. Future learned preprocessing must fit inside
training folds. Review README.md, dataset_config.json and verification.json before use.
